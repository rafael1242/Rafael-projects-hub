public class Main {

    public static final String ANSI_RESET = "\u001B[0m";
    public static final String ANSI_GREEN = "\u001B[32m";
    public static final String ANSI_YELLOW = "\u001B[33m";
    public static final String ANSI_RED = "\u001B[31m";
    public static final String ANSI_CLEAR = "\u001B[2J"; // Código para limpar a tela
    public static final String ANSI_HOME = "\u001B[H";   // Código para mover o cursor para o início

    public static void main(String[] args) {
        // Threads separadas para cada semáforo
        Thread XLight = new Thread(Main::XTrafficLight);
        Thread YLight = new Thread(Main::YTrafficLight);

        XLight.start();
        YLight.start();
    }

    public static void XTrafficLight() {
        while (true) {
            try {
                clearConsole(); // Limpa o console
                System.out.println(ANSI_GREEN + "RUA 2: Verde" + ANSI_RESET);
                Thread.sleep(10000); // Verde por 10 segundos

                clearConsole(); // Limpa o console
                System.out.println(ANSI_YELLOW + "RUA 2: Amarelo" + ANSI_RESET);
                Thread.sleep(3000); // Amarelo por 3 segundos

                clearConsole(); // Limpa o console
                System.out.println(ANSI_RED + "RUA 2: Vermelho" + ANSI_RESET);
                Thread.sleep(10000); // Vermelho por 10 segundos

            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public static void YTrafficLight() {
        while (true) {
            try {
                clearConsole(); // Limpa o console
                System.out.println(ANSI_RED + "RUA 1: Vermelho" + ANSI_RESET);
                Thread.sleep(10000); // Vermelho por 10 segundos

                clearConsole(); // Limpa o console
                System.out.println(ANSI_GREEN + "RUA 1: Verde" + ANSI_RESET);
                Thread.sleep(10000); // Verde por 10 segundos

                clearConsole(); // Limpa o console
                System.out.println(ANSI_YELLOW + "RUA 1: Amarelo" + ANSI_RESET);
                Thread.sleep(3000); // Amarelo por 3 segundos

            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    // Método para limpar o console
    private static void clearConsole() {
        System.out.print(ANSI_CLEAR + ANSI_HOME);
        System.out.flush();
    }
}